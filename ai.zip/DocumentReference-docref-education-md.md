# Diploma / Degree Verification — MD - Credentials PSV Primary Source IG v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Diploma / Degree Verification — MD**

## Example DocumentReference: Diploma / Degree Verification — MD

**status**: Current

**type**: Degree verification (MD)

> **content**

### Attachments

| | | |
| :--- | :--- | :--- |
| - | **ContentType** | **Url** |
| * | application/pdf | [https://registrar.stateu.example.edu/verify?degree=MD&student=1478523690](https://registrar.stateu.example.edu/verify?degree=MD&student=1478523690) |




## Resource Content

```json
{
  "resourceType" : "DocumentReference",
  "id" : "docref-education-md",
  "status" : "current",
  "type" : {
    "text" : "Degree verification (MD)"
  },
  "content" : [
    {
      "attachment" : {
        "contentType" : "application/pdf",
        "url" : "https://registrar.stateu.example.edu/verify?degree=MD&student=1478523690"
      }
    }
  ]
}

```
